COMP9517 Project:
Tianqi Liu (5019791)
Hanzhang Zeng (3493047)
Group Name: Roger Carl

The state data is about 200 MB which is too big to upload, 
instead we give you a small set of training data which you could use to run the program.

To use the program first run Trainer.py, then run Recogniser.py, for the function of each class, please refer to our report.

The configuration file is in config.py, which can be used for changing detection threshold and data path.

To quit our program, please press ESC